# VerboDrill — Spanish Verb Trainer

Audio-lingual Spanish verb conjugation trainer powered by Gemini AI.  
Drills 20 verbs × 4 tenses × 6 pronouns = 480 conjugations, with AI-generated grammar explanations on every card.

---

## Project Structure

```
verbodrill/
├── server.js          # Express server — proxies Gemini API calls
├── package.json
├── .gitignore
└── public/
    └── index.html     # Full single-file frontend
```

---

## Local Development

```bash
# Install dependencies
npm install

# Set your Gemini API key
export GEMINI_API_KEY=your_key_here

# Run the server
npm start
# → http://localhost:3000
```

---

## Deploy to Railway

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial VerboDrill commit"
git remote add origin https://github.com/YOUR_USERNAME/verbodrill.git
git push -u origin main
```

### 2. Create Railway Project
1. Go to [railway.app](https://railway.app) and click **New Project**
2. Choose **Deploy from GitHub Repo**
3. Select your `verbodrill` repository
4. Railway auto-detects Node.js and runs `npm start`

### 3. Add Environment Variable
In your Railway service dashboard:
- Go to **Variables** tab
- Add: `GEMINI_API_KEY` = `your_gemini_api_key_here`

### 4. Generate Domain
- Go to **Settings → Networking**
- Click **Generate Domain**
- Your app will be live at `https://verbodrill-production.up.railway.app`

---

## How It Works

- **Frontend** (`public/index.html`) posts to `/api/chat` with a Gemini prompt
- **Server** (`server.js`) reads `GEMINI_API_KEY` from env and proxies to Gemini's REST API
- **Model used:** `gemini-2.5-flash`
- The API key is never exposed to the browser

---

## Getting a Gemini API Key

1. Go to [aistudio.google.com](https://aistudio.google.com)
2. Click **Get API Key** → **Create API Key**
3. Copy the key and set it as `GEMINI_API_KEY` in Railway
